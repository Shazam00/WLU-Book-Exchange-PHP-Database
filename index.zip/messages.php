<?php

include("headeruser.php");

//get User ID

$query = "select UserID from Users where username = '$username'";
$result = mysql_query($query, $conn);
$data = mysql_fetch_array($result);
$uid = $data['UserID'];
echo '<h2>Pending Exchanges</h2>';

echo '<h3>Selling</h3>';
echo '<table border="1" width="400" >
	<tr>
	<th>Current Owner</th>
	<th>Book Title</th>
	<th>Author</th>
	<th>Course</th>
	<th>Price</th>
	<th>Book Exchanged</th>
	<th>Denied Trade</th>
	</tr>';
$query = "select  *  from Requests where (SellerID = '$uid')";
$result = mysql_query($query, $conn);
while($data = mysql_fetch_array( $result )) {
	$bid = $data['BookID'];
	$query = "select  *  from Books where (BookID = '$bid')";
	$r = mysql_query($query, $conn);
	$seller = $data['SellerID'];
	$query = "select username from Users where (UserID = '$seller')";
	$s = mysql_query($query, $conn);
	$sd = mysql_fetch_array($s);
	$d = mysql_fetch_array( $r);
	echo ' <tr>';
	echo ' <td>'.$sd['username'].'</td>';
	echo ' <td>'.$d['bookTitle'].'</td>';
	echo ' <td>'.$d['author'].'</td>';
	echo ' <td>'.$d['course'].'</td>';
	echo ' <td>'.$d['price'].'</td>';

	echo ' <td width="50">';
	echo '<form action="http://hopper.wlu.ca/~ramr0560/final/requestchange.php" method="post">';
	echo '<input type="hidden" name="RequestID" value='.$data['RequestID'].'>';
	echo '<input type="submit" name="bsubmit" value="Completed">';
	echo '</form>';
	echo ' </td>';


	echo ' <td width="50">';
	echo '<form action="http://hopper.wlu.ca/~ramr0560/final/requestchange.php" method="post">';
	echo '<input type="hidden" name="RequestID" value='.$data['RequestID'].'>';
	echo '<input type="submit" name="bsubmit" value="Declined">';
	echo '</form>';
	echo ' </td>';


	echo '	</tr>';
}
echo '</table><br/>';


echo '<h3>Buying</h3>';
echo '<table border="1" width="400" >
	<tr>
	<th>Current Owner</th>
	<th>Book Title</th>
	<th>Author</th>
	<th>Course</th>
	<th>Price</th>
	<th>Cancel Request</th>
	</tr>';
$query = "select  *  from Requests where (BuyerID = '$uid')";
$result = mysql_query($query, $conn);
while($data = mysql_fetch_array( $result )) {
	$bid = $data['BookID'];
	$query = "select  *  from Books where (BookID = '$bid')";
	$r = mysql_query($query, $conn);
	$seller = $data['SellerID'];
	$query = "select username from Users where (UserID = '$seller')";
	$s = mysql_query($query, $conn);
	$sd = mysql_fetch_array($s);
	$d = mysql_fetch_array( $r);
	echo ' <tr>';
	echo ' <td>'.$sd['username'].'</td>';
	echo ' <td>'.$d['bookTitle'].'</td>';
	echo ' <td>'.$d['author'].'</td>';
	echo ' <td>'.$d['course'].'</td>';
	echo ' <td>'.$d['price'].'</td>';

	echo ' <td width="50">';
	echo '<form action="http://hopper.wlu.ca/~ramr0560/final/requestchange.php" method="post">';
	echo '<input type="hidden" name="RequestID" value='.$data['RequestID'].'>';
	echo '<input type="submit" name="bsubmit" value="Cancel">';
	echo '</form>';
	echo ' </td>';


	echo '	</tr>';
}
echo '</table>';
echo '<hr/>';


echo '<h2>Friend Requests</h2>';



echo 'none<br/>';


echo '<h2>Messages</h2>';

echo 'none<br/>';

mysql_close($conn);
?>
