<html>

<body>

<?php

include("headeruser.php");
echo '<form action="http://hopper.wlu.ca/~ramr0560/final/getbookbycourse.php"  method="post">';
echo '<select name="course">';



$conn=mysql_connect("localhost","ramr0560","angr32cunt") or die(mysql_error());
mysql_select_db("ramr0560");

$sql="SELECT distinct course FROM Books";
$result = mysql_query($sql,$conn);

while($data = mysql_fetch_array($result))
  {
  echo '<option value="'.$data['course'].'">'.$data['course'].'</option>';
  }


echo '</select>';
echo '<input type="submit" name="viewBook" value="View Books" />';
echo '</form>';
echo '<hr/>';

mysql_close($conn);
?>


</body>
</html> 