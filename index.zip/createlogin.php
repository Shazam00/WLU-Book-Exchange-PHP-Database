<?php
echo 'test';
$username = $_POST['username'];
$password = sha1($_POST['password']); 
$vpassword = sha1($_POST['vpassword']); 
$email = $_POST['email'];

if($password !=  $vpassword ){
     	echo 'passwords dont match';
	exit;
}


$conn=mysql_connect("localhost","ramr0560","angr32cunt") or die(mysql_error());
mysql_select_db("ramr0560");


$query = "select count(*) from Users where username = '$username'";
$result = mysql_query($query, $conn);




if(!$result) {
      echo 'Cannot run query.';
      exit;
    }
    $row = mysql_fetch_row($result);
    $count = $row[0];
    
    if ( $count > 0 ) {
      // visitor's name and password combination are correct
      echo 'Error, username has been taken';
      exit;
    }
    else
    {
      // create user
	$query = "insert into Users (username, password, email) values ('$username','$password','$email') ";
	$result = mysql_query($query, $conn);
	echo 'User has been created! Please log in.';
    }
mysql_close($conn);
?>






