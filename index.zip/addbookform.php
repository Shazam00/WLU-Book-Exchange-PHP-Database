
<html>
<title>Laurier Book Exchange</title>

<?php

include("headeruser.php");

?>

<h1>Add New Book to Database</h1>
<form action="http://hopper.wlu.ca/~ramr0560/final/addbook.php" method="post">
<b>Book Entry</b><br/><br/>
Book Name <input type="text" name="bookname"  /><br />
Author <input type="text" name="author"   /><br />
Course Name <input type="text" name="course"   /><br />
Price <input type="text" name="price"   /><br /><br />
Add to my book list?<br/>
Yes<input type="radio" name="addbook"  value="yes" checked="checked"   /><br />
No<input type="radio" name="addbook"  value="no"   /><br />

<input type="submit" value="Add book"  />
</form>
</html>