<?php

session_start();
if (!(isset($_SESSION['login']) && $_SESSION['login'] != '')) {
	header ("Location: http://hopper.wlu.ca/~ramr0560/final");
}

$username = $_SESSION['login'];
$conn=mysql_connect("localhost","ramr0560","angr32cunt") or die(mysql_error());
mysql_select_db("ramr0560");

echo 'Username: ',$username;
echo '<br/>';
echo 'Inbox (0 new messages)';
echo '<br/>';
echo 'Friends';
echo '<br/>';
echo '<a href= logout.php>Log out</a>';
echo '<br/>';



echo '<hr/>';

?>


<?php

$toDelete = $_POST['select'];
if (empty($toDelete)) {
	echo("You didn't select any books!");
	exit;
} else {

	//get User ID
	$query = "select UserID from Users where username = '$username'";
	$result = mysql_query($query, $conn);
	$data = mysql_fetch_array($result);
	$uid = $data['UserID'];


	$D = count($toDelete);
	echo("You selected $D book(s): <br/>");
	for($i=0; $i < $D; $i++)
    	{
		$query = "delete from UserBook where UserID ='$uid' and BookID ='$toDelete[$i]' ";
		$result = mysql_query($query, $conn);
      		echo 'Deleted bookID: '.$toDelete[$i].' from UserID: '.$uid.' !!';
    	}
}

mysql_close($conn);
?>

<hr/>
<a href= userhome.php>Back to User Main Page</a>

