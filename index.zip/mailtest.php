<?php

$message = "this is a test message";
mail('ramr0560@mylaurier.ca', 'PHP mail test from hopper', $message);


?>