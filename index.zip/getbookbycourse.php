<?php

include("searchbycourse.php");


$course=$_POST["course"];
$conn=mysql_connect("localhost","ramr0560","angr32cunt") or die(mysql_error());
mysql_select_db("ramr0560");

$sql="SELECT * FROM Books WHERE course = '$course' ";
$result = mysql_query($sql,$conn);

echo "<table border='1'>
<tr>
<th>Select Book</th>
<th>Book Title</th>
<th>Author</th>
<th>Price</th>
</tr>";
echo '<form action="http://hopper.wlu.ca/~ramr0560/final/book.php" method="post">';

while($data = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo '<td><input type="checkbox" name="select[]" value='.$data['bookID'].'></td>';
  echo "<td>" . $data['bookTitle'] . "</td>";
  echo "<td>" . $data['author'] . "</td>";
  echo "<td>" . $data['price'] . "</td>";
  echo "</tr>";
  }
echo "</table>";
echo '<input type="submit" name="bsubmit" value="Add Books to your List" /><br/><br/>';
echo '<input type="submit" name="bsubmit" value="Request to buy book(s)" />';
echo '</form>';

mysql_close($conn);
?> 