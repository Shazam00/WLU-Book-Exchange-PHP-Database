<html>


<?php

include("headeruser.php");

?>

<br/>

<b>Display books here in table format</b><br/>


<?php



	//get User ID
	$query = "select UserID, email from Users where username = '$username'";
	$result = mysql_query($query, $conn);
	$data = mysql_fetch_array($result);
	//echo  'User id: '. $data['UserID'] . " ";
	$uid = $data['UserID'];
	$uemail = $data['email'];

	$query = "select  ub.UserID, ub.BookID , b.bookID, b.bookTitle, b.author, b.course, b.price  from Books b
		join UserBook ub on (ub.BookID = b.bookID) where (ub.UserID = '$uid')";
	$result = mysql_query($query, $conn);
	
	echo '<form action="http://hopper.wlu.ca/~ramr0560/final/deletebooks.php" method="post">';
	
	echo '<table border="1" width="400" >
	<tr>
	<th>Select Book</th>
	<th>Book Title</th>
	<th>Author</th>
	<th>Course</th>
	<th>Price</th>
	</tr>';

	while($data = mysql_fetch_array( $result )) {

	echo ' <tr>';
	echo ' <td><input type="checkbox" name="select[]" value='.$data['bookID'].'></td>';
	echo ' <td>'.$data['bookTitle'].'</td>';
	echo ' <td>'.$data['author'].'</td>';
	echo ' <td>'.$data['course'].'</td>';
	echo ' <td>'.$data['price'].'</td>';
	echo '	</tr>';
	}
	echo '</table>';

	echo '<input type="submit" name="delete" value="Delete Selected Books" />';
	echo '</form>';

	mysql_close($conn);
?>
<hr/>
<a href= search.php>Default Book name Search</a><br/>

<a href= searchbycourse.php>Search Books by Course</a><br/>


<a href= addbookform.php>Add book</a><br/>




</html>








