<?php

$username = $_POST['username'];
$password = sha1($_POST['password']); 

$conn=mysql_connect("localhost","ramr0560","angr32cunt") or die(mysql_error());
mysql_select_db("ramr0560");


$query = "select count(*) from Users where username = '$username' and password = '$password'";

$result = mysql_query($query, $conn);


if(!$result) {
      echo 'Cannot run query.';
      exit;
    }
    $row = mysql_fetch_row($result);
    $count = $row[0];
    
    if ( $count > 0 ) {
	// visitor's name and password combination are correct
	echo 'go to user home page';
	session_start();
	$_SESSION['login'] = $username;
	header ("Location: userhome.php");
    }
    else
    {
	// visitor's name and password combination are not correct
	echo 'incorrect username or password';
	session_start();
	$_SESSION['login'] = '';
	header( 'Location: http://hopper.wlu.ca/~ramr0560/final' ) ;
    }
mysql_close($conn);
?>