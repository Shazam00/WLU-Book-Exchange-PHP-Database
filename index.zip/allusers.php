<?php

include("headeruser.php");

?>

<?php


$conn=mysql_connect("localhost","ramr0560","angr32cunt") or die(mysql_error());
mysql_select_db("ramr0560");


$query = "select * from Users ORDER BY username ASC";

$result = mysql_query($query, $conn);

echo '<form action="http://hopper.wlu.ca/~ramr0560/final/modifyfriends.php" method="post">';

echo '<table border="1" width="400" >';


echo '<tr>';
echo '<th>Select User</th>';
echo '<th>Username</th>';
echo '<th>Owned Books</th>';
echo '</tr>';

while($data = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo '<td><input type="checkbox" name="select[]" value='.$data['UserID'].'></td>';
  echo "<td><a href=viewuserbooks.php?UserID=" . $data['UserID'] . ">".$data['username']."</td>";
  $q = "select count(*) from UserBook where UserID = ".$data['UserID']." ";
  $r = mysql_query($q, $conn);
  $owned = mysql_result($r, 0);
  echo "<td>" . $owned . "</td>";
  echo "</tr>";
  }
echo "</table>";

echo '<input type="submit" name="bsubmit" value="Add Selected to Friends" />';
echo '</form>';





mysql_close($conn);
?>

