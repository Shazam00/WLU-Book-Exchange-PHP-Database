<?php
include("search.php");
?>

<?php

$bookname = $_POST['bookname'];
$author = $_POST['author'];
$course = $_POST['course'];
$price = $_POST['price'];
$add = $_POST['addbook'];

if ($bookname == "") {
	$bookname = "$$$$";
}
if ($author == "") {
	$author = "$$$$";
}
if ($course == "") {
	$course = "$$$$";
}
if ($price == "") {
	$price = "$$$$";
}




$conn=mysql_connect("localhost","ramr0560","angr32cunt") or die(mysql_error());
mysql_select_db("ramr0560");
$query = "select * from Books where bookTitle LIKE '%".$bookname."%' OR author LIKE '%".$author."%' OR course LIKE '%".$course."%' OR price LIKE '%".$price."%' ";


$result = mysql_query($query, $conn);


echo '<form action="http://hopper.wlu.ca/~ramr0560/final/book.php" method="post">';


echo '<table border="1" width="400" >
<tr>
<th>Select Book</th>
<th>Book Title</th>
<th>Author</th>
<th>Course</th>
<th>Price</th>
</tr>';

while($data = mysql_fetch_array( $result )) {
	echo ' <tr>';
	echo ' <td><input type="checkbox" name="select[]" value='.$data['bookID'].'></td>';
	echo ' <td>'.$data['bookTitle'].'</td>';
	echo ' <td>'.$data['author'].'</td>';
	echo ' <td>'.$data['course'].'</td>';
	echo ' <td>'.$data['price'].'</td>';
	echo '	</tr>';
	}
	echo '</table>';
	echo '<input type="submit" name="bsubmit" value="Add Books to your List" /><br/><br/>';
	echo '<input type="submit" name="bsubmit" value="Request to buy book(s)" />';
	echo '</form>';

mysql_close($conn);
?>




