﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Laurier Book Exchange</title>
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!--[if lte IE 6]><link rel="stylesheet" href="css/ie6.css" type="text/css" media="all" /><![endif]-->

	<!-- JS -->
	<script src="js/jquery-1.4.1.min.js" type="text/javascript"></script>	
	<script src="js/jquery.jcarousel.pack.js" type="text/javascript"></script>	
	<script src="js/jquery-func.js" type="text/javascript"></script>	
	<!-- End JS -->
	
</head>
<body>
	
<!-- Shell -->	
<div class="shell">
	
	<!-- Header -->	
	<div id="header">
		<h1 id="logo"><a href="#">Laurier</a></h1>	
		
		<!-- Cart -->
		<div id="cart">
			<a href="#" class="cart-link">Logged in as: Shazam</a>
			<div class="cl">&nbsp;</div>
			<span>Books Owned: <strong>4</strong></span>
			&nbsp;&nbsp;
			<span>Pending: <strong>0</strong></span>
		</div>
		<!-- End Cart -->
		
		<!-- Navigation -->
		<div id="navigation">
			<ul>
			    <li><a href="#" class="active">Home</a></li>
			    <li><a href="#">Inbox</a></li>
			    <li><a href="#">Friends</a></li>
			    <li><a href="#">Users</a></li>
			    <li><a href="#">Contact</a></li>
			    <li><a href="#">Log out</a></li>
			</ul>
		</div>
		<!-- End Navigation -->
	</div>
	<!-- End Header -->
	
	<!-- Main -->
	<div id="main">
		<div class="cl">&nbsp;</div>
		
		<!-- Content -->
		<div id="content">
			
<?php

include("headeruser.php");

?>

<br/>

<b>Display books here in table format</b><br/>


<?php



	//get User ID
	$query = "select UserID, email from Users where username = '$username'";
	$result = mysql_query($query, $conn);
	$data = mysql_fetch_array($result);
	//echo  'User id: '. $data['UserID'] . " ";
	$uid = $data['UserID'];
	$uemail = $data['email'];

	$query = "select  ub.UserID, ub.BookID , b.bookID, b.bookTitle, b.author, b.course, b.price  from Books b
		join UserBook ub on (ub.BookID = b.bookID) where (ub.UserID = '$uid')";
	$result = mysql_query($query, $conn);
	
	echo '<form action="http://hopper.wlu.ca/~ramr0560/final/deletebooks.php" method="post">';
	
	echo '<table border="1" width="400" >
	<tr>
	<th>Select Book</th>
	<th>Book Title</th>
	<th>Author</th>
	<th>Course</th>
	<th>Price</th>
	</tr>';

	while($data = mysql_fetch_array( $result )) {

	echo ' <tr>';
	echo ' <td><input type="checkbox" name="select[]" value='.$data['bookID'].'></td>';
	echo ' <td>'.$data['bookTitle'].'</td>';
	echo ' <td>'.$data['author'].'</td>';
	echo ' <td>'.$data['course'].'</td>';
	echo ' <td>'.$data['price'].'</td>';
	echo '	</tr>';
	}
	echo '</table>';

	echo '<input type="submit" name="delete" value="Delete Selected Books" />';
	echo '</form>';

	mysql_close($conn);
?>
			
		</div>
		<!-- End Content -->
		
		<!-- Sidebar -->
		<div id="sidebar">
			
			<!-- Search -->
			<div class="box search">
				<h2>Search by <span></span></h2>
				<div class="box-content">
					<form action="" method="post">
						
						<label>Keyword</label>
						<input type="text" class="field" />
						
						<label>Category</label>
						<select class="field">
							<option value="">-- Select Course --</option>
							<option value="">CP104</option>
							<option value="">CP476</option>
							<option value="">BU491</option>
						</select>
						
						<div class="inline-field">
							<label>Price</label>
							<select class="field small-field">
								<option value="">Free!</option>
								<option value="">$10</option>
							</select>
							<label>to:</label>
							<select class="field small-field">
								<option value="">Free!</option>
								<option value="">$50</option>
							</select>
						</div>
						
						<input type="submit" class="search-submit" value="Search" />
						
						<p>
							<a href="#" class="bul">Advanced search</a><br />
						</p>
	
					</form>
				</div>
			</div>
			<!-- End Search -->
			
			<!-- Categories -->
			<div class="box categories">
				<h2>Recent Exchanges <span></span></h2>
				<div class="box-content">
					<ul>
					    <li><a href="#">Book 1</a></li>
					    <li><a href="#">Book 2</a></li>
					    <li><a href="#">Book 3</a></li>
					    <li><a href="#">Book 4</a></li>
					    <li><a href="#">Book 5</a></li>
					    <li><a href="#">Book 6</a></li>
					    <li><a href="#">Book 7</a></li>
					    <li><a href="#">Book 8</a></li>
					    <li><a href="#">Book 9</a></li>
					    <li><a href="#">Book 10</a></li>
					    <li><a href="#">Book 11</a></li>
					    <li><a href="#">Book 12</a></li>
					    <li class="last"><a href="#">Book 13</a></li>
					</ul>
				</div>
			</div>
			<!-- End Categories -->
			
		</div>
		<!-- End Sidebar -->
		
		<div class="cl">&nbsp;</div>
	</div>
	<!-- End Main -->
	
	<!-- Side Full -->
	<div class="side-full">
		
		<!-- More Products -->

		<!-- End More Products -->
		
		<!-- Text Cols -->
		<div class="cols">
			<div class="cl">&nbsp;</div>
			<div class="col">
				<h3 class="ico ico1">Exchange Books</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec imperdiet, metus ac cursus auctor, arcu felis ornare dui.</p>
			</div>
			<div class="col">
				<h3 class="ico ico2">Make Friends</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec imperdiet, metus ac cursus auctor, arcu felis ornare dui.</p>
			</div>
			<div class="col">
				<h3 class="ico ico3">GoodWill</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec imperdiet, metus ac cursus auctor, arcu felis ornare dui.</p>
			</div>
			<div class="col col-last">
				<h3 class="ico ico4">Save Money!</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec imperdiet, metus ac cursus auctor, arcu felis ornare dui.</p>
			</div>
			<div class="cl">&nbsp;</div>
		</div>
		<!-- End Text Cols -->
		
	</div>
	<!-- End Side Full -->
	
	<!-- Footer -->

	<!-- End Footer -->
	
</div>	
<!-- End Shell -->
</body>
</html>