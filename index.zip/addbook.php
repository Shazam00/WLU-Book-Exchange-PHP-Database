<?php

session_start();
if (!(isset($_SESSION['login']) && $_SESSION['login'] != '')) {
	header ("Location: http://hopper.wlu.ca/~ramr0560/final");
}

$username = $_SESSION['login'];


$bookname = $_POST['bookname'];
$author = $_POST['author'];
$course = $_POST['course'];
$price = $_POST['price'];
$add = $_POST['addbook'];



// add entry to the database
$conn=mysql_connect("localhost","ramr0560","angr32cunt") or die(mysql_error());

mysql_select_db("ramr0560");

$query = "insert into Books (bookTitle, author, course, price) values ('$bookname','$author','$course','$price') ";
$result = mysql_query($query, $conn);


if($add == 'yes') {
	// connect the user id to book id in the OwnedBooks lookup table
	

	//get User ID
	$query = "select UserID from Users where username = '$username'";
	$result = mysql_query($query, $conn);
	$data = mysql_fetch_array($result);
	//echo  'User id: '. $data['UserID'] . " ";
	$uid = $data['UserID'];

	echo '<br/>';
	// get book id
	$query = "select bookID from Books where bookTitle = '$bookname'";
	$result = mysql_query($query, $conn);
	$data = mysql_fetch_array( $result );
	//Print 'book id: '.$data['bookID'] . " ";
	$bid = $data['bookID'];

	//add it to the look up table
	$query = "insert into UserBook (UserID, BookID) values ('$uid','$bid') ";
	$result = mysql_query($query, $conn);
}



mysql_close($conn);
?>