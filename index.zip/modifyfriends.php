<?php


include("headeruser.php");


$conn=mysql_connect("localhost","ramr0560","angr32cunt") or die(mysql_error());
mysql_select_db("ramr0560");


$toChange = $_POST['select'];

if (empty($toChange)) {
	echo("You didn't select any anybody!");
	exit;
}

//get User ID
$query = "select UserID from Users where username = '$username'";
$result = mysql_query($query, $conn);
$data = mysql_fetch_array($result);
$uid = $data['UserID'];

$D = count($toChange);
echo $D;

switch ($_POST['bsubmit']) {
	case 'Remove Selected from Friends':
		for($i=0; $i < $D; $i++) {
			$query = "delete from FriendList where UserID = '$uid' and FriendID = '$toChange[$i]' ";
			$result = mysql_query($query, $conn);
     			echo 'Remove FriendID: '.$toChange[$i].' To UserID: '.$uid.' !!';
    		}
		break;
	case 'Add Selected to Friends':
		for($i=0; $i < $D; $i++) {
			$query = "insert into FriendList (UserID, FriendID) values ('$uid','$toChange[$i]') ";
			$result = mysql_query($query, $conn);
      			echo 'Add FriendID: '.$toChange[$i].' To UserID: '.$uid.' !!';
    		}
		break;
}

mysql_close($conn);
?>