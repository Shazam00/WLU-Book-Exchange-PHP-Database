<?php

include("headeruser.php");



$uid = $_GET['UserID'];

$query = "select username from Users where UserID = '$uid'";
$result = mysql_query($query, $conn);
$data = mysql_result($result,0);

echo 'Viewing '.$data,' s books';


$query = "select  ub.UserID, ub.BookID , b.bookID, b.bookTitle, b.author, b.course, b.price  from Books b
		join UserBook ub on (ub.BookID = b.bookID) where (ub.UserID = '$uid')";
	$result = mysql_query($query, $conn);
	
	echo '<form action="http://hopper.wlu.ca/~ramr0560/final/book.php" method="post">';
	
	echo '<table border="1" width="400" >
	<tr>
	<th>Select Book</th>
	<th>Book Title</th>
	<th>Author</th>
	<th>Course</th>
	<th>Price</th>
	</tr>';

	while($data = mysql_fetch_array( $result )) {

	echo ' <tr>';
	echo ' <td><input type="checkbox" name="select[]" value='.$data['bookID'].'></td>';
	echo ' <td>'.$data['bookTitle'].'</td>';
	echo ' <td>'.$data['author'].'</td>';
	echo ' <td>'.$data['course'].'</td>';
	echo ' <td>'.$data['price'].'</td>';
	echo '	</tr>';
	}
	echo '</table>';

	echo '<input type="submit" name="bsubmit" value="Request to buy book(s)" />';
	echo '</form>';
mysql_close($conn);
?>