<?php

include("headeruser.php");

$conn=mysql_connect("localhost","ramr0560","angr32cunt") or die(mysql_error());
mysql_select_db("ramr0560");

$toAdd = $_POST['select'];

if (empty($toAdd)) {
	echo("You didn't select any books!");
	exit;
}

switch ($_POST['bsubmit']) {

case 'Add Books to your List':
	//get User ID
	$query = "select UserID from Users where username = '$username'";
	$result = mysql_query($query, $conn);
	$data = mysql_fetch_array($result);
	$uid = $data['UserID'];
	$uemail = $data['email'];
	$D = count($toAdd);
	echo("You selected $D book(s): <br/>");
	for($i=0; $i < $D; $i++)
    	{
		$query = "insert into UserBook (UserID, BookID) values ('$uid','$toAdd[$i]') ";
		$result = mysql_query($query, $conn);
      		echo 'Add bookID: '.$toAdd[$i].' To UserID: '.$uid.' !!';
    	}
	echo ' added book(s) to list';
	break;

case 'Request to buy book(s)':

	echo 'Requested to buy selected book(s)';

	//get User ID
	$query = "select UserID from Users where username = '$username'";
	$result = mysql_query($query, $conn);
	$data = mysql_fetch_array($result);
	$uid = $data['UserID'];

	$query = "select email from Users where username = '$username'";
	$result = mysql_query($query, $conn);
	$data = mysql_fetch_array($result);
	$uemail = $data['email'];

	// send a request to buy books by bookId to first UserID
	$D = count($toAdd);
	echo("You selected $D book(s): <br/>");
	for($i=0; $i < $D; $i++)
    	{
		$query = "select * from Books where (BookID = '$toAdd[$i]')";
		$result = mysql_query($query, $conn);
		$data = mysql_fetch_array($result);
		$bid = $toAdd[$i];
		$booktitle = $data['bookTitle'];
		$author = $data['author'];
		$course = $data['course'];
		$price = $data['price'];

		$query = "select u.UserID, u.username, u.email from Users u join UserBook ub on (u.UserID = ub.UserID) where (ub.BookID = '$toAdd[$i]')";
		$result = mysql_query($query, $conn);
		$data = mysql_fetch_array($result);
		$rid = $data['username'];
		$sid = $data['UserID'];	
		$email = $data['email'];
		
		
		echo 'Requested owner of your interest:<br/>';
		echo '<hr/>';
		echo 'To: '.$email.'<br/>';
		echo 'Subject: Laurier Book Exchange Request</br>';
		echo 'Body: '.$username.' would like to buy '.$booktitle.' from you.<br/> ';
		echo 'Let him/her know if you are willing to make an exchange at</br>';
		echo $uemail;
		
		$query = "insert into Requests (SellerID, BuyerID, BookID) values  ('$sid','$uid', '$bid')";
		$result = mysql_query($query, $conn);
    	}



	break;

mysql_close($conn);
}



?>