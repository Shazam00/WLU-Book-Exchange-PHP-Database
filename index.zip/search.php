<?php


include("headeruser.php");






?>


<html>
<title>Laurier Book Exchange</title>
<h1>Search books in Database</h1>
<form action="http://hopper.wlu.ca/~ramr0560/final/searchbooks.php" method="post">
<b>Enter Specifications</b><br/><br/>
Book Name <input type="text" name="bookname"  /><br />
Author <input type="text" name="author"   /><br />
Course Name <input type="text" name="course"   /><br />
Price <input type="text" name="price"   /><br /><br />
<input type="submit" value="Search Books"  />
</form>
<hr>
</html>