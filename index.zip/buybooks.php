<?php

include("headeruser.php");

$conn=mysql_connect("localhost","ramr0560","angr32cunt") or die(mysql_error());
mysql_select_db("ramr0560");

$toBuy = $_POST['select'];


if (empty($toBuy)) {
	echo("You didn't select any books!");
	exit;
} else {

	//get User ID
	$query = "select UserID from Users where username = '$username'";
	$result = mysql_query($query, $conn);
	$data = mysql_fetch_array($result);
	$uid = $data['UserID'];
	$D = count($toAdd);
	echo("You selected $D book(s): <br/>");
	for($i=0; $i < $D; $i++)
    	{
		$query = "insert into UserBook (UserID, BookID) values ('$uid','$toAdd[$i]') ";
		$result = mysql_query($query, $conn);
      		echo 'Add bookID: '.$toDelete[$i].' To UserID: '.$uid.' !!';
    	}
}
echo ' added book(s)';


echo("Request(s) sent.");

mysql_close($conn);





?>