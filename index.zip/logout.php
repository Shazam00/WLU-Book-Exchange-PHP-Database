<?php
	session_start();
	session_destroy();
	header ("Location: http://hopper.wlu.ca/~ramr0560/final");
?>