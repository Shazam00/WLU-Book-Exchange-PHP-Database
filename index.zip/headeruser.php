<?php

session_start();
if (!(isset($_SESSION['login']) && $_SESSION['login'] != '')) {
	header ("Location: http://hopper.wlu.ca/~ramr0560/final");
}

$username = $_SESSION['login'];
$conn=mysql_connect("localhost","ramr0560","angr32cunt") or die(mysql_error());
mysql_select_db("ramr0560");


$date=getdate(time());
echo " ".$date['weekday']." ".$date['month']." ".$date['mday'].", ".$date['year'];
echo "<br/>Current Time: ".$date['hours'].":".$date['minutes']." ";

echo '<br/>Logged in as: <b>'.$username.'</b>';
echo '<br/>';
echo '<a href= logout.php>Log out</a>';
echo '<br/>';


echo '<hr/>';
echo '<a href= userhome.php>User Home</a> | <a href= messages.php>Inbox</a> | <a href= viewfriends.php>View Friends</a> | <a href= allusers.php>View All Users</a>';
echo '<hr/>';

?>